<?
$arTemplate = array (
  'NAME' => 'Шаблон сайта clearbitrix',
  'DESCRIPTION' => 'Базовый шаблон для начала разработки',
  'SORT' => '',
  'TYPE' => '',
);
?>