<?
$MESS ['T_IBLOCK_VOTE_RESULTS'] = "(votes: #VOTES#, rating: #RATING#)";
$MESS ['T_IBLOCK_VOTE_NO_RESULTS'] = "(no votes)";
?>