<?
$MESS ['FORM_CURRENT_STATUS'] = "Current status: ";
$MESS ['FORM_MODULE_NOT_INSTALLED'] = "Web-form module is not installed.";
$MESS ['FORM_RECORD_NOT_FOUND'] = "Record not found";
$MESS ['FORM_RESULT_ACCESS_DENIED'] = "Result access denied.";
$MESS ['FORM_ACCESS_DENIED'] = "Web-form access denied.";
$MESS ['FORM_EDIT'] = "Edit";
$MESS ['FORM_PRINT'] = "Print";
$MESS ['FORM_FORM_NAME'] = "Form:";
$MESS ['FORM_DATE_CREATE'] = "Created:";
$MESS ['FORM_TIMESTAMP'] = "Modified:";
$MESS ['FORM_USER'] = "User:";
$MESS ['FORM_EDIT_USER'] = "User profile";
$MESS ['FORM_NOT_AUTH'] = "(not authorized)";
$MESS ['FORM_NOT_REGISTERED'] = "(not registered)";
$MESS ['FORM_GUEST'] = "Visitor:";
$MESS ['FORM_GUEST_ALT'] = "Visitor profile";
$MESS ['FORM_SESSION'] = "Session:";
$MESS ['FORM_VIEW_FILE'] = "View file";
$MESS ['FORM_DOWNLOAD_FILE'] = "Download file #FILE_NAME#";
$MESS ['FORM_DOWNLOAD'] = "Download";
?>